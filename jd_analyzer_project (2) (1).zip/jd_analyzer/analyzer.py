"""Core Job Description analysis logic (pure Python, no third-party packages)."""

import re
from collections import Counter
from dataclasses import dataclass, field, asdict

from skills_db import SKILLS, RED_FLAGS, STOPWORDS

PREF_HINT = re.compile(
    r"nice to have|good to have|preferred|bonus|a plus|is a plus|advantage|desirable|optional", re.I)
REQ_HINT = re.compile(
    r"must have|must-have|required|requirements|mandatory|essential|qualifications|what you(?:'ll)? need|you have", re.I)


@dataclass
class SkillHit:
    name: str
    category: str
    count: int
    priority: str  # "required" or "preferred"


@dataclass
class AnalysisResult:
    job_title: str = "Not detected"
    word_count: int = 0
    avg_sentence_length: float = 0.0
    seniority: str = "Not specified"
    experience: str = "Not specified"
    education: list = field(default_factory=list)
    work_mode: list = field(default_factory=list)
    employment_type: list = field(default_factory=list)
    salary: list = field(default_factory=list)
    skills: list = field(default_factory=list)       # list[SkillHit]
    top_keywords: list = field(default_factory=list)  # list[(word, count)]
    red_flags: list = field(default_factory=list)     # list[dict]
    notes: list = field(default_factory=list)
    quality_score: int = 100

    def to_dict(self):
        return asdict(self)


# ---------------------------------------------------------------- helpers
def _skill_pattern(alias: str) -> re.Pattern:
    # custom word boundaries so c++, c#, .net, node.js work properly
    return re.compile(r"(?<![A-Za-z0-9+#])" + re.escape(alias) + r"(?![A-Za-z0-9+#])", re.I)


_PATTERNS = []
for _cat, _skills in SKILLS.items():
    for _name, _aliases in _skills.items():
        _PATTERNS.append((_cat, _name, [_skill_pattern(a) for a in _aliases]))


def _lines(text: str):
    return [ln.strip() for ln in re.split(r"[\r\n]+", text) if ln.strip()]


# ---------------------------------------------------------------- extractors
def extract_skills(text: str) -> list:
    """Find known skills; mark each as required/preferred based on surrounding wording."""
    hits = {}
    section = "required"
    for line in _lines(text):
        short = len(line) <= 70
        if short and PREF_HINT.search(line):
            section = "preferred"
        elif short and REQ_HINT.search(line):
            section = "required"
        line_priority = "preferred" if PREF_HINT.search(line) else section

        for cat, name, patterns in _PATTERNS:
            n = sum(len(p.findall(line)) for p in patterns)
            if not n:
                continue
            if name not in hits:
                hits[name] = SkillHit(name, cat, 0, line_priority)
            hits[name].count += n
            if line_priority == "required":      # required anywhere wins
                hits[name].priority = "required"
    return sorted(hits.values(), key=lambda h: (-h.count, h.name))


def extract_experience(text: str) -> str:
    rng = re.search(r"(\d{1,2})\s*(?:\+)?\s*(?:-|–|to)\s*(\d{1,2})\s*\+?\s*(?:years?|yrs?)", text, re.I)
    if rng:
        return f"{rng.group(1)}-{rng.group(2)} years"
    single = re.search(r"(?:minimum|at least|min\.?)?\s*(\d{1,2})\s*\+?\s*(?:years?|yrs?)", text, re.I)
    if single:
        plus = "+" if re.search(single.group(1) + r"\s*\+|at least|minimum", single.group(0), re.I) else ""
        return f"{single.group(1)}{plus} years"
    if re.search(r"\bfreshers?\b|entry[- ]level|no experience|0\s*years", text, re.I):
        return "Fresher / entry level"
    return "Not specified"


def extract_education(text: str) -> list:
    mapping = {
        "Bachelor's degree": r"bachelor|b\.?\s?tech|b\.?\s?e\b|b\.?\s?sc|bca\b|\bbs\b|b\.?\s?com",
        "Master's degree": r"master|m\.?\s?tech|m\.?\s?sc|mca\b|\bms\b|\bmba\b",
        "PhD": r"ph\.?\s?d|doctorate",
        "Diploma": r"diploma",
        "Computer Science / IT background": r"computer science|information technology|\bcse\b|software engineering",
    }
    return [k for k, v in mapping.items() if re.search(v, text, re.I)]


def extract_work_mode(text: str) -> list:
    modes = []
    if re.search(r"\bhybrid\b", text, re.I):
        modes.append("Hybrid")
    if re.search(r"\bremote\b|work from home|\bwfh\b", text, re.I):
        modes.append("Remote / WFH")
    if re.search(r"on[- ]?site|work from office|\bwfo\b|in[- ]office", text, re.I):
        modes.append("On-site")
    return modes


def extract_employment_type(text: str) -> list:
    types = {
        "Full-time": r"full[- ]?time",
        "Part-time": r"part[- ]?time",
        "Contract": r"\bcontract(?:ual)?\b",
        "Internship": r"\bintern(?:ship)?\b|\bstipend\b",
        "Freelance": r"freelance",
    }
    return [k for k, v in types.items() if re.search(v, text, re.I)]


def extract_salary(text: str) -> list:
    cur = r"(?:₹|rs\.?|inr|\$|usd|€|eur|£|gbp)"
    unit = r"(?:k|lpa|lakhs?|lacs?|cr|crores?|m|million)?"
    num = r"\d[\d,]*(?:\.\d+)?"
    patterns = [
        rf"{cur}\s?{num}\s?{unit}(?:\s?(?:-|–|to)\s?{cur}?\s?{num}\s?{unit})?(?:\s?(?:per|/|a)\s?(?:annum|year|yr|month|mo|hour|hr))?",
        rf"{num}(?:\s?(?:-|–|to)\s?{num})?\s?(?:lpa|lakhs?|lacs?)(?:\s?per annum)?",
    ]
    found = []
    for p in patterns:
        for m in re.finditer(p, text, re.I):
            s = m.group(0).strip()
            if s and any(c.isdigit() for c in s) and s not in found:
                found.append(s)
    return found[:5]


def detect_seniority(text: str, title: str, experience: str) -> str:
    probe = (title + " " + text[:400]).lower()
    order = [
        ("Intern / Trainee", r"\bintern\b|\btrainee\b"),
        ("Principal / Architect", r"\bprincipal\b|\barchitect\b|\bstaff engineer\b"),
        ("Manager / Head", r"\bmanager\b|\bhead of\b|\bdirector\b"),
        ("Lead", r"\blead\b|\btech lead\b"),
        ("Senior", r"\bsenior\b|\bsr\.?\b"),
        ("Junior / Entry", r"\bjunior\b|\bjr\.?\b|\bfresher\b|\bentry[- ]level\b|\bassociate\b"),
        ("Mid-level", r"\bmid[- ]?level\b|\bintermediate\b"),
    ]
    for label, pat in order:
        if re.search(pat, probe):
            return label
    m = re.search(r"(\d+)", experience)
    if m:
        y = int(m.group(1))
        return "Junior / Entry" if y <= 1 else "Mid-level" if y <= 4 else "Senior" if y <= 8 else "Lead / Principal"
    return "Not specified"


def guess_title(text: str) -> str:
    m = re.search(r"(?:job title|position|role|designation)\s*[:\-]\s*(.+)", text, re.I)
    if m:
        return m.group(1).strip()[:80]
    for line in _lines(text)[:3]:
        if 3 <= len(line) <= 80 and not line.endswith("."):
            return line
    return "Not detected"


def top_keywords(text: str, n: int = 12) -> list:
    words = re.findall(r"[A-Za-z][A-Za-z+#.\-]{2,}", text.lower())
    words = [w.strip(".-") for w in words]
    counts = Counter(w for w in words if w and w not in STOPWORDS and len(w) > 2)
    return counts.most_common(n)


def detect_red_flags(text: str) -> list:
    flags = []
    for pattern, severity, message in RED_FLAGS:
        m = re.search(pattern, text, re.I)
        if m:
            flags.append({"phrase": m.group(0), "severity": severity, "message": message})
    return flags


# ---------------------------------------------------------------- main API
def analyze(text: str) -> AnalysisResult:
    if not text or not text.strip():
        raise ValueError("Job description is empty.")

    r = AnalysisResult()
    words = re.findall(r"\b\w+\b", text)
    sentences = [s for s in re.split(r"[.!?\n]+", text) if s.strip()]
    r.word_count = len(words)
    r.avg_sentence_length = round(len(words) / max(len(sentences), 1), 1)

    r.job_title = guess_title(text)
    r.experience = extract_experience(text)
    r.seniority = detect_seniority(text, r.job_title, r.experience)
    r.education = extract_education(text)
    r.work_mode = extract_work_mode(text)
    r.employment_type = extract_employment_type(text)
    r.salary = extract_salary(text)
    r.skills = extract_skills(text)
    r.top_keywords = top_keywords(text)
    r.red_flags = detect_red_flags(text)

    # transparency notes + quality score
    score = 100
    penalty = {"low": 4, "medium": 8, "high": 15}
    for f in r.red_flags:
        score -= penalty[f["severity"]]
    if not r.salary:
        r.notes.append("Salary / pay range is not mentioned.")
        score -= 10
    if not r.work_mode:
        r.notes.append("Work mode (remote / hybrid / on-site) is not mentioned.")
        score -= 5
    if r.experience == "Not specified":
        r.notes.append("Required experience is not clearly stated.")
        score -= 5
    if not r.skills:
        r.notes.append("No recognised technical skills found - JD may be too vague.")
        score -= 15
    if r.word_count < 80:
        r.notes.append("Very short JD - responsibilities may be unclear.")
        score -= 10
    if r.word_count > 900:
        r.notes.append("Very long JD - may be unfocused.")
        score -= 5
    if len([s for s in r.skills if s.category != "Soft Skills"]) > 15:
        r.notes.append("Asks for 15+ technical skills - likely an unrealistic wish list.")
        score -= 8
    r.quality_score = max(0, min(100, score))
    return r
