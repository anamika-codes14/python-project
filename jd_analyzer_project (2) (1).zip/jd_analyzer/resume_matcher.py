"""Compare a resume against the skills found in a job description."""

from dataclasses import dataclass, field
from analyzer import extract_skills


@dataclass
class MatchResult:
    score: int = 0
    matched_required: list = field(default_factory=list)
    missing_required: list = field(default_factory=list)
    matched_preferred: list = field(default_factory=list)
    missing_preferred: list = field(default_factory=list)
    extra_skills: list = field(default_factory=list)   # in resume, not in JD
    verdict: str = ""


def match_resume(jd_skills: list, resume_text: str) -> MatchResult:
    """Score = weighted overlap: required skills count 2x, preferred skills 1x."""
    if not resume_text or not resume_text.strip():
        raise ValueError("Resume text is empty.")

    resume_names = {h.name for h in extract_skills(resume_text)}
    jd_names = {h.name for h in jd_skills}
    m = MatchResult()

    for h in jd_skills:
        found = h.name in resume_names
        if h.priority == "required":
            (m.matched_required if found else m.missing_required).append(h.name)
        else:
            (m.matched_preferred if found else m.missing_preferred).append(h.name)
    m.extra_skills = sorted(resume_names - jd_names)

    total = 2 * (len(m.matched_required) + len(m.missing_required)) \
        + (len(m.matched_preferred) + len(m.missing_preferred))
    got = 2 * len(m.matched_required) + len(m.matched_preferred)
    m.score = round(100 * got / total) if total else 0

    m.verdict = (
        "Excellent match - apply with confidence." if m.score >= 80 else
        "Good match - tailor your resume to cover the missing skills." if m.score >= 60 else
        "Partial match - upskill on the missing required skills first." if m.score >= 40 else
        "Low match - this role needs significant new skills."
    )
    return m
