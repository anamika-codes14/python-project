"""Command-line interface."""

import argparse
import sys

from analyzer import analyze
from resume_matcher import match_resume
from file_reader import read_file
from report import build_text_report, save_report


def run(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="JDAnalyzer",
        description="Analyze a job description (skills, experience, red flags) and optionally match your resume.")
    ap.add_argument("--jd", help="Path to job description file (.txt/.md/.docx). Omit to read from stdin.")
    ap.add_argument("--resume", help="Optional resume file (.txt/.md/.docx) to compute a match score.")
    ap.add_argument("--out", help="Save report to this path (.txt or .json).")
    args = ap.parse_args(argv)

    try:
        jd_text = read_file(args.jd) if args.jd else sys.stdin.read()
        result = analyze(jd_text)
        match = match_resume(result.skills, read_file(args.resume)) if args.resume else None
    except (ValueError, OSError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    print(build_text_report(result, match))
    if args.out:
        save_report(args.out, result, match)
        print(f"\nReport saved to {args.out}")
    return 0
