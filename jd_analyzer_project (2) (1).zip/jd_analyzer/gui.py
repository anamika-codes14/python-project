"""Tkinter desktop GUI."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from analyzer import analyze
from resume_matcher import match_resume
from file_reader import read_file
from report import build_text_report, save_report

FILETYPES = [("Text / Word", "*.txt *.md *.docx"), ("All files", "*.*")]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Job Description Analyzer")
        self.geometry("920x680")
        self.minsize(760, 520)
        self.result = None
        self.match = None
        self._build_ui()

    # ------------------------------------------------------------ UI
    def _build_ui(self):
        top = ttk.Frame(self, padding=(10, 8))
        top.pack(fill="x")
        ttk.Button(top, text="Analyze", command=self.on_analyze).pack(side="left")
        ttk.Button(top, text="Save report...", command=self.on_save).pack(side="left", padx=6)
        ttk.Button(top, text="Clear", command=self.on_clear).pack(side="left")
        self.status = ttk.Label(top, text="Paste a job description and click Analyze.")
        self.status.pack(side="right")

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.jd_box = self._make_tab("1. Job Description", "Open JD file...", self.on_open_jd)
        self.resume_box = self._make_tab("2. Resume (optional)", "Open resume file...", self.on_open_resume)

        report_frame = ttk.Frame(self.tabs)
        self.tabs.add(report_frame, text="3. Report")
        self.report_box = self._text_widget(report_frame, mono=True)
        self.report_box.configure(state="disabled")

    def _make_tab(self, title, btn_text, cmd):
        frame = ttk.Frame(self.tabs, padding=6)
        self.tabs.add(frame, text=title)
        ttk.Button(frame, text=btn_text, command=cmd).pack(anchor="w", pady=(0, 6))
        holder = ttk.Frame(frame)
        holder.pack(fill="both", expand=True)
        return self._text_widget(holder)

    @staticmethod
    def _text_widget(parent, mono=False):
        box = tk.Text(parent, wrap="word", undo=True, padx=8, pady=8,
                      font=("Consolas", 10) if mono else ("Segoe UI", 10))
        sb = ttk.Scrollbar(parent, command=box.yview)
        box.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        box.pack(side="left", fill="both", expand=True)
        return box

    # ------------------------------------------------------------ actions
    def _load_into(self, box):
        path = filedialog.askopenfilename(filetypes=FILETYPES)
        if not path:
            return
        try:
            text = read_file(path)
        except Exception as e:
            messagebox.showerror("Cannot open file", str(e))
            return
        box.delete("1.0", "end")
        box.insert("1.0", text)

    def on_open_jd(self):
        self._load_into(self.jd_box)

    def on_open_resume(self):
        self._load_into(self.resume_box)

    def on_analyze(self):
        jd = self.jd_box.get("1.0", "end").strip()
        resume = self.resume_box.get("1.0", "end").strip()
        try:
            self.result = analyze(jd)
            self.match = match_resume(self.result.skills, resume) if resume else None
        except ValueError as e:
            messagebox.showwarning("Input needed", str(e))
            return
        self._show_report(build_text_report(self.result, self.match))
        self.tabs.select(2)
        self.status.config(text=f"Done - JD quality {self.result.quality_score}/100"
                           + (f", resume match {self.match.score}%" if self.match else ""))

    def _show_report(self, text):
        self.report_box.configure(state="normal")
        self.report_box.delete("1.0", "end")
        self.report_box.insert("1.0", text)
        self.report_box.configure(state="disabled")

    def on_save(self):
        if not self.result:
            messagebox.showinfo("Nothing to save", "Run an analysis first.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text report", "*.txt"), ("JSON", "*.json")])
        if path:
            save_report(path, self.result, self.match)
            self.status.config(text=f"Saved: {path}")

    def on_clear(self):
        for box in (self.jd_box, self.resume_box):
            box.delete("1.0", "end")
        self._show_report("")
        self.result = self.match = None
        self.tabs.select(0)
        self.status.config(text="Cleared.")


def launch():
    App().mainloop()
