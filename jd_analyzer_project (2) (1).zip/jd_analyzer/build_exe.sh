#!/usr/bin/env bash
# Builds a single-file executable for Linux/macOS: dist/JDAnalyzer
set -e
python3 -m pip install --upgrade pyinstaller
python3 -m PyInstaller --onefile --name JDAnalyzer main.py
echo "Done! Your app is at: dist/JDAnalyzer"
