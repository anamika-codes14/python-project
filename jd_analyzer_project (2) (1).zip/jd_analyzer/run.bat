@echo off
REM Double-click to start the Job Description Analyzer (needs Python installed)
where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw main.py
) else (
    python main.py
    pause
)
