"""Entry point.

  JDAnalyzer                      -> opens the GUI
  JDAnalyzer --jd jd.txt [...]    -> command-line mode
"""

import sys


def main() -> int:
    if len(sys.argv) > 1:
        from cli import run
        return run()
    try:
        from gui import launch
    except ImportError:
        print("Tkinter not available - use CLI mode:  python main.py --jd job.txt")
        return 1
    launch()
    return 0


if __name__ == "__main__":
    sys.exit(main())
