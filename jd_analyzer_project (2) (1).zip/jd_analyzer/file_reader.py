"""Read text from .txt / .md / .docx files using only the standard library."""

import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree

W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _read_docx(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        root = ElementTree.fromstring(z.read("word/document.xml"))
    paragraphs = []
    for p in root.iter(W_NS + "p"):
        paragraphs.append("".join(t.text or "" for t in p.iter(W_NS + "t")))
    return "\n".join(paragraphs)


def read_file(path) -> str:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")
    ext = p.suffix.lower()
    if ext == ".docx":
        return _read_docx(p)
    if ext == ".pdf":
        raise ValueError("PDF not supported. Please copy-paste the text or save it as .txt / .docx.")
    for enc in ("utf-8", "utf-8-sig", "cp1252", "latin-1"):
        try:
            return p.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Could not decode {p.name}")
