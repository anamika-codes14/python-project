# Job Description Analyzer

Analyzes a job description and shows: title, seniority, experience, education, work mode,
salary, skills (required vs preferred), top keywords, red flags and a JD quality score.
Optionally matches your resume against the JD and lists missing skills.

## Project structure
| File | Purpose |
|---|---|
| `main.py` | Entry point (GUI by default, CLI if arguments are given) |
| `analyzer.py` | Core analysis logic |
| `skills_db.py` | Skills list, red-flag phrases, stopwords (edit to extend) |
| `resume_matcher.py` | Resume vs JD skill match score |
| `file_reader.py` | Reads .txt / .md / .docx |
| `report.py` | Text / JSON report builder |
| `cli.py` | Command-line interface |
| `gui.py` | Tkinter desktop GUI |

## Run
    Double-click run.bat   (Windows, Python installed)
    python main.py                                   # GUI
    python main.py --jd samples/sample_jd.txt --resume samples/sample_resume.txt --out report.json

## Build the executable
- Windows: double-click `build_exe.bat`  ->  `dist\JDAnalyzer.exe`
- Linux/macOS: `./build_exe.sh`  ->  `dist/JDAnalyzer`

An executable only runs on the OS it was built on, so build the .exe on Windows.

No Windows PC to build on? Push this folder to GitHub, open Actions -> 'Build Windows EXE' -> Run workflow,
then download JDAnalyzer.exe from the run's Artifacts.
