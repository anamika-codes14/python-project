@echo off
REM Builds a single-file Windows executable: dist\JDAnalyzer.exe
python -m pip install --upgrade pyinstaller
python -m PyInstaller --onefile --windowed --name JDAnalyzer main.py
echo.
echo Done! Your app is at: dist\JDAnalyzer.exe
pause
