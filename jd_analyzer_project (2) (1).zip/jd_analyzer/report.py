"""Turn analysis results into readable text / JSON reports."""

import json
from collections import defaultdict

LINE = "=" * 62
SUB = "-" * 62


def _bar(score: int, width: int = 20) -> str:
    filled = round(width * score / 100)
    return "[" + "#" * filled + "." * (width - filled) + f"] {score}/100"


def _fmt_list(items, empty="Not specified"):
    return ", ".join(items) if items else empty


def build_text_report(result, match=None) -> str:
    out = []
    add = out.append
    add(LINE)
    add("  JOB DESCRIPTION ANALYSIS REPORT")
    add(LINE)
    add(f"Job title        : {result.job_title}")
    add(f"Seniority        : {result.seniority}")
    add(f"Experience       : {result.experience}")
    add(f"Education        : {_fmt_list(result.education)}")
    add(f"Work mode        : {_fmt_list(result.work_mode)}")
    add(f"Employment type  : {_fmt_list(result.employment_type)}")
    add(f"Salary mentioned : {_fmt_list(result.salary, 'No')}")
    add(f"Length           : {result.word_count} words, avg {result.avg_sentence_length} words/sentence")
    add(f"JD quality score : {_bar(result.quality_score)}")

    add("\n" + SUB + "\nSKILLS FOUND\n" + SUB)
    if result.skills:
        grouped = defaultdict(list)
        for s in result.skills:
            tag = "" if s.priority == "required" else " (preferred)"
            grouped[s.category].append(f"{s.name}{tag}" + (f" x{s.count}" if s.count > 1 else ""))
        for cat, items in grouped.items():
            add(f"{cat}:\n   " + ", ".join(items))
    else:
        add("No known skills detected.")

    add("\n" + SUB + "\nTOP KEYWORDS\n" + SUB)
    add(", ".join(f"{w} ({c})" for w, c in result.top_keywords) or "-")

    add("\n" + SUB + "\nRED FLAGS\n" + SUB)
    if result.red_flags:
        for f in result.red_flags:
            add(f"[{f['severity'].upper():6}] \"{f['phrase']}\" - {f['message']}")
    else:
        add("None found. Looks clean!")

    if result.notes:
        add("\n" + SUB + "\nMISSING / UNCLEAR INFO\n" + SUB)
        for n in result.notes:
            add(f"- {n}")

    if match is not None:
        add("\n" + LINE + "\n  RESUME MATCH\n" + LINE)
        add(f"Match score : {_bar(match.score)}")
        add(f"Verdict     : {match.verdict}")
        add(f"Matched (required)  : {_fmt_list(match.matched_required, '-')}")
        add(f"MISSING (required)  : {_fmt_list(match.missing_required, '-')}")
        add(f"Matched (preferred) : {_fmt_list(match.matched_preferred, '-')}")
        add(f"Missing (preferred) : {_fmt_list(match.missing_preferred, '-')}")
        add(f"Extra skills on resume: {_fmt_list(match.extra_skills, '-')}")

    add("\n" + LINE)
    return "\n".join(out)


def build_json_report(result, match=None) -> str:
    data = result.to_dict()
    if match is not None:
        data["resume_match"] = match.__dict__
    return json.dumps(data, indent=2, ensure_ascii=False)


def save_report(path: str, result, match=None) -> None:
    content = build_json_report(result, match) if str(path).lower().endswith(".json") \
        else build_text_report(result, match)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
